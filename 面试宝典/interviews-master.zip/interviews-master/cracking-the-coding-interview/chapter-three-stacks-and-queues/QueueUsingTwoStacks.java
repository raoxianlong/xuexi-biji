/* implement a MyQueue class which implements a queue using two stacks */

public class QueueUsingTwoStacks {
	
}